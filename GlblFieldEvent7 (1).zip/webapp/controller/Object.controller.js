/*global location*/
sap.ui.define([
	"technipfmc/gfe/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"technipfmc/gfe/model/formatter",
	"sap/m/MessageBox"
], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	MessageBox
) {
	"use strict";
	var reqElemData, that = this;
	return BaseController.extend("technipfmc.gfe.controller.Object", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay, oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});

			reqElemData = [{
				elem: "cDescription"
			}, {
				elem: "cInputDT"
					//	}, {
					//		elem: "cInputTime"
			}, {
				elem: "cEventDT"
					//	}, {
					//		elem: "cEventTime"
			}, {
				elem: "cEventDesc"
			}, {
				elem: "cZzafld00000e"
			}, {
				elem: "cZzafld000008"
					//	}, {
					//		elem: "cprdline"
			}, {
				elem: "cZzfld00001w"
			}, {
				elem: "cZzfld00001x"
			}, {
				elem: "cZzfld00001y"
			}, {
				elem: "cZzfld00001t"
			}, {
				elem: "cZzfld00001u"
			}, {
				elem: "cZzfld00001v"
			}, {
				elem: "cZzafld000000"
			}, {
				elem: "cZzafld000001"
			}, {
				elem: "cZzafld000003"
			}, {
				elem: "cProjectPrtnr_PartnerNo"
			}, {
				elem: "cClientPrtnr_PartnerNo"
			}, {
				elem: "cEvtOwner_PartnerNo"
			}, {
				elem: "cZzafld00000i"
			}, {
				elem: "cZzafld000005"
			}, {
				elem: "cZzafld000022"
			}, {
				elem: "cZzafld000022"
			}, {
				elem: "cZzafld000004"
			}, {
				elem: "cZzprocedure"
			}, {
				elem: "cZzrevision"
			}, {
				elem: "cZzafld000007"
			}, {
				elem: "cZzafld000021"
			}, {
				elem: "cZzCatId"
			}];

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			// Sets the text to the label
			this.getView().byId("headerAttachments").addEventDelegate({
				onBeforeRendering: function() {
					this.getView().byId("attachmentTitle").setText(this.getAttachmentTitleText());
					this.getView().byId("evtAtt").setProperty("count", this.getView().byId("headerAttachments").getItems().length);
				}.bind(this)
			});
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("objectView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();
			this.getView().unbindObject();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		onSemanticButtonPress: function() {
			window.print();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("FieldEventExtSet", {
					Guid: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();
			oDataModel.setSizeLimit(500);
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}
			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.Guid,
				sObjectName = oObject.ObjectId;
			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject", oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage", oResourceBundle.getText("shareSendEmailObjectMessage", [
				sObjectName,
				sObjectId,
				location.href
			]));
		},
		_formFragments: {},
		_showFormFragment: function(sFragmentName) {
			var oIconTab = this.getView().byId("evtTab");
			oIconTab.removeAllContent();
			oIconTab.insertContent(this._getFormFragment(sFragmentName));
		},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];
			if (oFormFragment) {
				return oFormFragment;
			}
			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "technipfmc.gfe.view." + sFragmentName, this);
			return this._formFragments[sFragmentName] = oFormFragment;
		},
		_toggleButtonsAndView: function(bEdit) {
			var oView = this.getView();
			// Show the appropriate action buttons
			oView.byId("editEvt").setVisible(!bEdit);
			oView.byId("saveEvt").setVisible(bEdit);
			oView.byId("cancelEvt").setVisible(bEdit);
			oView.byId("fileUploader").setEnabled(bEdit);
			//oView.byId("fileUploaderBut").setEnabled(bEdit);
			// Set the right form type
			this._showFormFragment(bEdit ? "Change" : "Display");
		},
		getAttachmentTitleText: function() {
			var aItems = this.getView().byId("headerAttachments").getItems();
			return "Attachments (" + aItems.length + ")";
		},
		formatAttribute: function(sValue) {
			jQuery.sap.require("sap.ui.core.format.FileSizeFormat");
			if (jQuery.isNumeric(sValue)) {
				return sap.ui.core.format.FileSizeFormat.getInstance({
					binaryFilesize: false,
					maxFractionDigits: 1,
					maxIntegerDigits: 3
				}).format(sValue);
			} else {
				return sValue;
			}
		},
		stime: function(value) {
			jQuery.sap.require("sap.ui.core.format.DateFormat");
			//                             console.log(value);                        
			if (value) {

				var date = new Date(value.ms);
				//                             console.log("date po value.ms: "+ date);
				var timeinmiliseconds = date.getTime(); //date.getTime(); //date.getSeconds(); //date.getTime();
				//                             console.log(timeinmiliseconds);
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "KK:mm:ss a"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				//                             console.log(TZOffsetMs);
				var timeStr = oTimeFormat.format(new Date(timeinmiliseconds + TZOffsetMs));
				//                             console.log(timeStr);

				return timeStr;
			} else {
				return value;
			}
		},

		/** ---------------------------------------------------------------------------------
		 **  method onAttachmentsUpdateFinished
		 **  Put number of Attachments on tab counter.
		 * @param {object} oEvent  The event object from the press event
		 **----------------------------------------------------------------------------------*/
		onAttachmentsUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total");
			this.getView().byId("evtAtt").setProperty("count", iTotalItems);
			this.getView().byId("attachmentTitle").setText("Attachments (" + iTotalItems + ")");
		}, //onAttachmentsUpdateFinished

		/**
		 *@memberOf technipfmc.controller.Object
		 */
		onEditEvent: function() {
			//This code was generated by the layout editor.
			this._toggleButtonsAndView(true);
		},
		/**
		 *@memberOf technipfmc.controller.Object
		 */
		onSaveEvent: function() {

			var oView = this.getView();
			var errExist;
			var dModel = this.getModel();
			//This code was generated by the layout editor.
			for (var x = 0; x < reqElemData.length; x++) {
				if (oView.byId(reqElemData[x].elem).getMetadata().getName() !== "sap.m.Select") {
					if (!oView.byId(reqElemData[x].elem).getValue()) {
						oView.byId(reqElemData[x].elem).setValueState("Error");
						errExist = true;
					} else {
						oView.byId(reqElemData[x].elem).setValueState("None");
					}
				}
				if (oView.byId(reqElemData[x].elem).getMetadata().getName() === "sap.m.Select") {
					if (!oView.byId(reqElemData[x].elem).getSelectedKey()) {
						oView.byId(reqElemData[x].elem).setValueState("Error");
						errExist = true;
					} else {
						oView.byId(reqElemData[x].elem).setValueState("None");
					}
				}
			}

			if (errExist) {
				MessageBox.error("Please fill all the required fields.");
				//MessageToast.show("Please fill all the required fields.");
				return;
			}

			/*	if (dModel.hasPendingChanges()) {
					that = this;
					dModel.submitChanges({
						success: function(aData, response) {
							MessageBox.success("Field Event successfully saved.", {
								onClose: function() {
									that._toggleButtonsAndView(false);
									that.getModel().refresh();
									that.getView().unbindObject();
									that.getRouter().navTo("worklist");
								}
							});
						}, // model read success
						error: function(aData, response) {
								MessageBox.error("Field Event changes could not be saved.");
							} // model read success
					});
				} else {*/
			that = this;
			dModel.submitChanges();
			MessageBox.success("Field Event successfully saved.", {
				onClose: function() {
					that._toggleButtonsAndView(false);
					that.getModel().refresh();
					that.getView().unbindObject();
					that.getRouter().navTo("worklist");
				}
			});
			//}
		},
		/**
		 *@memberOf technipfmc.controller.Object
		 */
		onCancelEvent: function() {
			//This code was generated by the layout editor.
			for (var x = 0; x < reqElemData.length; x++) {
				this.getView().byId(reqElemData[x].elem).setValueState("None");
			}
			this.getModel().resetChanges();
			this._toggleButtonsAndView(false);
		},

		onWorkListPress: function() {
			this.getView().unbindObject();
			this.getRouter().navTo("worklist");
		},
		/** ---------------------------------------------------------------------------------
		 **  method displayAttachment
		 **  Display one attachment.
		 * @param {object} oEvent  The event object from the press event
		 **----------------------------------------------------------------------------------*/
		onAttDisplayPress: function(oEvent) {
				var oDataFound = oEvent.getSource().getBindingContext().getObject();
				//------------------------ Open a window with file content ------------------------------
				// Convert to byteArray
				if (oDataFound) {
					//------------------------ Open a window with file content ------------------------------
					var decodedData = atob(oDataFound.FileContent);
					// Decode from base64
					// Convert to byteArray
					var byteNumbers = new Array(decodedData.length);
					for (var i = 0; i < decodedData.length; i++) {
						byteNumbers[i] = decodedData.charCodeAt(i);
					}
					// for
					var byteArrays = [new Uint8Array(byteNumbers)];
					// BLOB for file save
					var oBlob = new Blob(byteArrays, {
						type: oDataFound.MimeType
					});
					if (window.navigator.msSaveBlob) {
						// IE hack - see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
						window.navigator.msSaveOrOpenBlob(oBlob, oDataFound.FileName);
					} else {
						if (!sap.hybrid) {
							var a = window.document.createElement("a");
							a.href = window.URL.createObjectURL(oBlob, {
								type: oDataFound.MimeType
							});
							a.download = oDataFound.FileName;
							// Name of file
							document.body.appendChild(a);
							a.click();
							document.body.removeChild(a);
						} else {
							window.open(window.URL.createObjectURL(oBlob, {
								type: oDataFound.MimeType
							}));
						}
					} // if
				} // File content found
			} // displayAttachment
			,
		/*
		 *@memberOf technipfmc.controller.Object
		 */
		onFileUploadComplete: function(oEvent) {

			var oViewDet = this.getView();
			var sRefGuid = oViewDet.getBindingContext().getProperty("Guid"); // Guid
			var oModel = this.getModel();

			// ------------------------- Read file content ----------------------------------
			var oFileUploader = this.getView().byId("fileUploader");
			var oFile = jQuery.sap.domById(oFileUploader.getId() + "-fu").files[0];

			var sFileName = oFile.name; // Name of file
			var sMimeType = oFile.type; // Type of file
			var sFilesize = oFile.size;

			var sBase64Mark = "data:" + oFile.type + ";base64,"; // File content prefix to remove
			var oReader = new FileReader(); // Set up file reader
			var date = new Date();
			var sObjId = date.getTime().toString();
			var re =
				/(\.|\/)(bat|exe|cmd|sh|php([0-9])?|pl|cgi|386|dll|com|torrent|js|app|jar|pif|vb|vbscript|wsf|asp|cer|csr|jsp|drv|sys|ade|adp|bas|chm|cpl|crt|csh|fxp|hlp|hta|inf|ins|isp|jse|htaccess|htpasswd|ksh|lnk|mdb|mde|mdt|mdw|msc|msi|msp|mst|ops|pcd|prg|reg|scr|sct|shb|shs|url|vbe|vbs|wsc|wsf|wsh)$/i;

			if (sFilesize > 40000000) {
				MessageBox.error("File Size exceeds the limit of 40 MB.");
				return;
			}
			if (re.exec(sFileName)) {
				MessageBox.error("This file type is not allowed for upload.");
				return;
			}
			// ---------------------- Routine to start when file loaded ------------------------
			oReader.onload = function(oFileRead) {
				// Locate base64 content
				var iBase64Index = oFileRead.target.result.indexOf(sBase64Mark) + sBase64Mark.length;
				// Get base64 content
				var sFileContent = oFileRead.target.result.substring(iBase64Index);

				var aData = { // Backend action record&nbsp;
					//	RefHandle: "",
					RefGuid: sRefGuid,
					ObjId: sObjId,
					FileName: sFileName,
					MimeType: sMimeType,
					FileSize: sFilesize,
					FileContent: sFileContent
				};
				//var sPathAction = "/AttachmentSet";
				var sPathAction = oViewDet.getBindingContext().getPath() + "/FieldEvent_Attach_nav";
				var infMsg;
				oModel.create(sPathAction,
					aData, {
						groupId: sRefGuid,
						changeSetId: sRefGuid,
						success: function(oData, Response) {
							//	var oError = oData.__batchResponses[0].response;
							infMsg = "Attachment uploaded successfully.";
							sap.m.MessageToast.show(
								infMsg, {
									duration: 6000,
									width: "25%"
								});
						},
						error: function(error) {} // error
					});
			}; // oReader.onload function

			oReader.readAsDataURL(oFile); // Read file encoded to base64
		},

		/** ---------------------------------------------------------------------------------
		 **  method onCSELAttachDelete
		 **  Delete selected attachments.
		 * @param {object} oEvent  The event object from the press event
		 **----------------------------------------------------------------------------------*/
		onFileDeleted: function(oEvent) {
			if (this.getView().byId("fileUploader").getEnabled()) {
				var oModel = this.getView().getModel();
				var sPath = oEvent.getSource().getBindingContext().getPath(); // Path to file
				oModel.remove(sPath, function success() {}, function failure() {});
			}
		},

		onChangeValue: function(oEvent) {
			//			var control = evt.getParameter("element");
			//				if (control && control.setValueState) {
			//					control.setValueState("Error");			
			if (oEvent.getSource().getValueState() === "Error") {
				oEvent.getSource().setValueState("None");
			}

			switch (oEvent.getParameter("id")) {
				case this.getView().createId("cZzafld000000"):
					if (oEvent.getParameter("value") !== "" && oEvent.getParameter("value") !== "NA") {
						this.getView().byId("cZzafld000001").setValue("NA");
						if (this.getView().byId("cZzafld000001").getValueState() === "Error") {
							this.getView().byId("cZzafld000001").setValueState("None");
						}
					}
					break;

				case this.getView().createId("cZzafld000001"):
					if (oEvent.getParameter("value") !== "" && oEvent.getParameter("value") !== "NA") {
						this.getView().byId("cZzafld000000").setValue("NA");
						if (this.getView().byId("cZzafld000000").getValueState() === "Error") {
							this.getView().byId("cZzafld000000").setValueState("None");
						}
					}
					break;
			}

		},

		onValueHelpPart: function(oEvent) {
				var oView = this.getView();
				// Keep view for value popup
				// Value help for Engineer Id -------------------------------------------------------
				if (!this.oValueHelpDialogPart) {
					// Dialog window not already defined
					// =================== Set up selection dialog window ==========================
					// Create  Dialog + and we attach this as helper
					this.oValueHelpDialogPart = new sap.m.SelectDialog("cpartValueDialog", {
						title: "Assembly Part Selection Helper",
						noDataText: "No Parts Found",
						rememberSelections: false,
						// Remember previous selection
						confirm: function(oEvent1) {
							// Value selected ----------------------
							// Value from selection – assign value to the field in view
							oView.byId("cZzfld00001w").setValue(oEvent1.getParameter("selectedItem").getTitle());
							oView.byId("cZzfld00001w").setDescription(oEvent1.getParameter("selectedItem").getDescription());
							if (oView.byId("cZzfld00001w").getValueState() === "Error") {
								oView.byId("cZzfld00001w").setValueState("None");
							}
							oView.byId("cZzfld00001w").focus();
						},
						// confirm
						search: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						}, // Search
						cancel: function() {
							oView.byId("cZzfld00001w").focus();
						}
					}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
				}
				// if no exisiting dialog object
				//				var oModelF4 = this.getModel("ALLF4");
				this.oValueHelpDialogPart.setModel(this.getView().getModel());
				var itemTemplate = new sap.m.StandardListItem({
					title: "{ProductId}",
					description: "{ShortText}"
				});
				this.oValueHelpDialogPart.bindAggregation("items", "/F4ProductSet", itemTemplate);
				this.oValueHelpDialogPart.open(this.oValueHelpDialogPart._sSearchFieldValue);
			} // onValueHelpPart
			,

		onValueHelpPartfp: function(oEvent) {
				var oView = this.getView();
				// Keep view for value popup
				// Value help for Engineer Id -------------------------------------------------------
				if (!this.oValueHelpDialogPartfp) {
					// Dialog window not already defined
					// =================== Set up selection dialog window ==========================
					// Create  Dialog + and we attach this as helper
					this.oValueHelpDialogPartfp = new sap.m.SelectDialog("cpartValueDialogfp", {
						title: "Assembly Part Selection Helper",
						noDataText: "No Parts Found",
						rememberSelections: false,
						// Remember previous selection
						confirm: function(oEvent1) {
							// Value selected ----------------------
							// Value from selection – assign value to the field in view
							oView.byId("cZzfld00001u").setValue(oEvent1.getParameter("selectedItem").getTitle());
							oView.byId("cZzfld00001u").setDescription(oEvent1.getParameter("selectedItem").getDescription());
							if (oView.byId("cZzfld00001u").getValueState() === "Error") {
								oView.byId("cZzfld00001u").setValueState("None");
							}
							oView.byId("cZzfld00001u").focus();
						},
						// confirm
						search: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						}, // Search
						cancel: function() {
							oView.byId("cZzfld00001u").focus();
						}
					}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
				}
				// if no exisiting dialog object
				//				var oModelF4 = this.getModel("ALLF4");
				this.oValueHelpDialogPartfp.setModel(this.getView().getModel());
				var itemTemplate = new sap.m.StandardListItem({
					title: "{ProductId}",
					description: "{ShortText}"
				});
				this.oValueHelpDialogPartfp.bindAggregation("items", "/F4ProductSet", itemTemplate);
				this.oValueHelpDialogPartfp.open(this.oValueHelpDialogPartfp._sSearchFieldValue);
			} // onValueHelpPart
			,

		/**
		 *@memberOf technipfmc.controller.CreateEvt
		 */
		onValueHelpSerial: function() {
			var oView = this.getView();
			// Keep view for value popup
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogSer) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogSer = new sap.m.SelectDialog("cserialValueDialog", {
					title: "Assembly Serial Selection Helper",
					noDataText: "No Serial Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("cZzfld00001y").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("cZzfld00001y").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("cZzfld00001x").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("cZzfld00001w").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("cZzfld00001y").getValueState() === "Error") {
							oView.byId("cZzfld00001y").setValueState("None");
						}
						if (oView.byId("cZzfld00001x").getValueState() === "Error") {
							oView.byId("cZzfld00001x").setValueState("None");
						}
						if (oView.byId("cZzfld00001w").getValueState() === "Error") {
							oView.byId("cZzfld00001w").setValueState("None");
						}
						oView.byId("cZzfld00001y").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3serNo", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cZzfld00001y").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogSer.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3serNo}",
				description: "Equipment : {R3ident} - {ShortText}",
				info: "Material : {R3matId}"
			});
			this.oValueHelpDialogSer.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogSer.open(this.oValueHelpDialogSer._sSearchFieldValue);
		},

		onValueHelpSerialfp: function() {
			var oView = this.getView();
			// Keep view for value popup
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogSerfp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogSerfp = new sap.m.SelectDialog("cserialValueDialogfp", {
					title: "Assembly Serial Selection Helper",
					noDataText: "No Serial Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("cZzorderadmH1109").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("cZzorderadmH1109").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject(
							"ShortText"));
						oView.byId("cZzafld00003m").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("cZzfld00001u").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("cZzorderadmH1109").getValueState() === "Error") {
							oView.byId("cZzorderadmH1109").setValueState("None");
						}
						if (oView.byId("cZzafld00003m").getValueState() === "Error") {
							oView.byId("cZzafld00003m").setValueState("None");
						}
						if (oView.byId("cZzfld00001u").getValueState() === "Error") {
							oView.byId("cZzfld00001u").setValueState("None");
						}
						oView.byId("cZzorderadmH1109").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3serNo", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cZzorderadmH1109").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogSerfp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3serNo}",
				description: "Equipment : {R3ident} - {ShortText}",
				info: "Material : {R3matId}"
			});
			this.oValueHelpDialogSerfp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogSerfp.open(this.oValueHelpDialogSerfp._sSearchFieldValue);
		},

		onValueHelpEquip: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogEqp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogEqp = new sap.m.SelectDialog("ceqpValueDialog", {
					title: "Assembly Equipment Selection Helper",
					noDataText: "No Equipment Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("cZzfld00001y").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("cZzfld00001y").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("cZzfld00001x").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("cZzfld00001w").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("cZzfld00001y").getValueState() === "Error") {
							oView.byId("cZzfld00001y").setValueState("None");
						}
						if (oView.byId("cZzfld00001x").getValueState() === "Error") {
							oView.byId("cZzfld00001x").setValueState("None");
						}
						if (oView.byId("cZzfld00001w").getValueState() === "Error") {
							oView.byId("cZzfld00001w").setValueState("None");
						}
						oView.byId("cZzfld00001y").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3ident", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cZzfld00001y").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogEqp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3ident} - {ShortText}",
				description: "Material : {R3matId}",
				info: "Serial : {R3serNo}"
			});
			this.oValueHelpDialogEqp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogEqp.open(this.oValueHelpDialogEqp._sSearchFieldValue);
		},

		onValueHelpEquipfp: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogEqpfp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogEqpfp = new sap.m.SelectDialog("ceqpValueDialogfp", {
					title: "Assembly Equipment Selection Helper",
					noDataText: "No Equipment Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("cZzorderadmH1109").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("cZzorderadmH1109").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject(
							"ShortText"));
						oView.byId("cZzafld00003m").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("cZzfld00001u").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("cZzorderadmH1109").getValueState() === "Error") {
							oView.byId("cZzorderadmH1109").setValueState("None");
						}
						if (oView.byId("cZzafld00003m").getValueState() === "Error") {
							oView.byId("cZzafld00003m").setValueState("None");
						}
						if (oView.byId("cZzfld00001u").getValueState() === "Error") {
							oView.byId("cZzfld00001u").setValueState("None");
						}
						oView.byId("cZzorderadmH1109").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3ident", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cZzorderadmH1109").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogEqpfp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3ident} - {ShortText}",
				description: "Material : {R3matId}",
				info: "Serial : {R3serNo}"
			});
			this.oValueHelpDialogEqpfp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogEqpfp.open(this.oValueHelpDialogEqpfp._sSearchFieldValue);
		},

		onValueHelpClient: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogClnt) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogClnt = new sap.m.SelectDialog("cclntValueDialog", {
					title: "Customer Selection Helper",
					noDataText: "No Customer Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cClientPrtnr_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cClientPrtnr_PartnerNo").getModel().setProperty(oView.byId("cClientPrtnr_PartnerNo").getBindingContext().getPath() +
							"/ClientPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						//oView.getModel("CreateEvt").setProperty("/ClientPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("cClientPrtnr_PartnerNo").getValueState() === "Error") {
							oView.byId("cClientPrtnr_PartnerNo").setValueState("None");
						}
						oView.byId("cClientPrtnr_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cClientPrtnr_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search											
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogClnt.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "CRM000");
			this.oValueHelpDialogClnt.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogClnt.open(this.oValueHelpDialogClnt._sSearchFieldValue);
		},

		onValueHelpOwner: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogOwner) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogOwner = new sap.m.SelectDialog("cownValueDialog", {
					title: "Owner Selection Helper",
					noDataText: "No Owner Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cEvtOwner_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cEvtOwner_PartnerNo").getModel().setProperty(oView.byId("cEvtOwner_PartnerNo").getBindingContext().getPath() +
							"/EvtOwner/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("cEvtOwner_PartnerNo").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						//oView.getModel("CreateEvt").setProperty("/ProjectPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("cEvtOwner_PartnerNo").getValueState() === "Error") {
							oView.byId("cEvtOwner_PartnerNo").setValueState("None");
						}
						oView.byId("cEvtOwner_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cEvtOwner_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search						
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogOwner.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "BUP003");
			this.oValueHelpDialogOwner.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogOwner.open(this.oValueHelpDialogOwner._sSearchFieldValue);
		},

		onValueHelpPrj: function(oEvent) {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogPrj) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogPrj = new sap.m.SelectDialog("cprjValueDialog", {
					title: "Project Selection Helper",
					noDataText: "No Project Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cProjectPrtnr_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("cProjectPrtnr_PartnerNo").getModel().setProperty(oView.byId("cProjectPrtnr_PartnerNo").getBindingContext().getPath() +
							"/ProjectPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						//oView.getModel("CreateEvt").setProperty("/ProjectPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("cProjectPrtnr_PartnerNo").getValueState() === "Error") {
							oView.byId("cProjectPrtnr_PartnerNo").setValueState("None");
						}
						oView.byId("cProjectPrtnr_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("cProjectPrtnr_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search						
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogPrj.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "ZPROJE");
			this.oValueHelpDialogPrj.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogPrj.open(this.oValueHelpDialogPrj._sSearchFieldValue);
		}

	});
});