/*global location*/
sap.ui.define([
	"technipfmc/gfe/controller/BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"technipfmc/gfe/model/formatter"
], function(BaseController, MessageToast, JSONModel, MessageBox, History, formatter) {
	"use strict";
	var oData, sGuid, reqElemData, that = this;
	return BaseController.extend("technipfmc.gfe.controller.CreateEvt", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf technipfmc.view.CreateEvt
		 */
		onInit: function() {

			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay, oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});

			this.getRouter().getRoute("createevt").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			reqElemData = [{
				elem: "Description"
			}, {
				elem: "InputDT"
					//			}, {
					//				elem: "InputTime"
			}, {
				elem: "EventDT"
					//			}, {
					//				elem: "EventTime"
			}, {
				elem: "EventDesc"
			}, {
				elem: "Zzafld00000e"
			}, {
				elem: "Zzafld000008"
					//			}, {
					//				elem: "prdline"
			}, {
				elem: "Zzfld00001w"
			}, {
				elem: "Zzfld00001x"
			}, {
				elem: "Zzfld00001y"
			}, {
				elem: "Zzfld00001t"
			}, {
				elem: "Zzfld00001u"
			}, {
				elem: "Zzfld00001v"
			}, {
				elem: "Zzafld000000"
			}, {
				elem: "Zzafld000001"
			}, {
				elem: "Zzafld000003"
			}, {
				elem: "ProjectPrtnr_PartnerNo"
			}, {
				elem: "ClientPrtnr_PartnerNo"
			}, {
				elem: "EvtOwner_PartnerNo"
			}, {
				elem: "Zzafld00000i"
			}, {
				elem: "Zzafld000005"
			}, {
				elem: "Zzafld000022"
			}, {
				elem: "Zzafld000022"
			}, {
				elem: "Zzafld000004"
			}, {
				elem: "Zzprocedure"
			}, {
				elem: "Zzrevision"
			}, {
				elem: "Zzafld000007"
			}, {
				elem: "Zzafld000021"
			}, {
				elem: "ZzCatId"
			}];

			/*if (sap.hybrid) {
				this.byId("fileUploaderCrt").setVisible(false);
				this.byId("fileUploaderButCrt").setVisible(true);
			}*/
			// Register the view with the message manager
			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			// attach handlers for validation errors
			/**sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});**/
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();
			this.getView().unbindObject("CreateEvt");
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			//			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				// set data model on view
				oData = {
					Guid: "",
					ObjectId: "",
					ProcessType: "",
					PostingDate: null,
					Description: "",
					DescrLanguage: "",
					LogicalSystem: "",
					CreatedAt: null,
					CreatedBy: "",
					ChangedAt: null,
					ChangedBy: "",
					ZzorderadmH1109: "",
					Zzafld000000: "",
					Zzafld000001: "",
					Zzafld000002: "",
					Zzafld000003: "",
					Zzafld000004: "",
					Zzafld000005: "",
					Zzafld000007: "",
					Zzafld000008: "",
					Zzafld00000c: null,
					Zzafld00000d: null,
					Zzafld00000e: "",
					Zzafld00000f: "",
					Zzafld00000g: "",
					Zzafld00000h: "",
					Zzafld00000i: "",
					Zzafld00000j: "",
					Zzafld00000m: "",
					Zzafld000021: "",
					Zzafld000022: "",
					Zzafld000027: "",
					Zzafld00003h: "",
					Zzafld00003i: "",
					Zzafld00003k: "",
					Zzafld00003m: "",
					Zzfld000002: "",
					Zzfld00001p: new Date(),
					Zzfld00001q: null,
					Zzfld00001r: null,
					Zzfld00001s: null,
					Zzfld00001t: "",
					Zzfld00001u: "",
					Zzfld00001v: "",
					Zzfld00001w: "",
					Zzfld00001x: "",
					Zzfld00001y: "",
					Zzfld00001z: "",
					Zzprocedure: "",
					Zzrevision: "",
					ZzAccDowntime: "",
					ZzAccNProdtime: "",
					ZzStatus: "Submitted",
					ZzAspId: "SRV",
					ZzCatId: "",
					EventDesc: {
						Tdid: "",
						Tdtext: ""
					},
					Observer: {
						PartnerFct: "00000151",
						PartnerNo: "",
						Fullname: "Name"
					},
					ClientPrtnr: {
						PartnerFct: "00000001",
						PartnerNo: "",
						Fullname: ""
					},
					ProjectPrtnr: {
						PartnerFct: "00000003",
						PartnerNo: "",
						Fullname: ""
					},
					EvtCorrDesc: {
						Tdid: "",
						Tdtext: ""
					},
					EvtOwner: {
						PartnerFct: "00000014",
						PartnerNo: "",
						Fullname: ""
					},
					FieldEvent_Attach_nav: []
				};
				var oModel = new JSONModel(oData);
				this.getView().setModel(oModel, "CreateEvt");

				//			var oModel = this.getView().getModel("CreateEvt");
				var dModel = this.getView().getModel();
				dModel.setSizeLimit(500);
				var sObjectPath = dModel.createKey("/F4UserSet", {
					uname: "X"
				});
				if (sap.hybrid) {
					sObjectPath = "/F4UserSet";
				}
				that = this;
				dModel.read(sObjectPath, {
					success: function(aData, response) {
						var locData = aData;
						if (sap.hybrid) {
							locData = aData.results[0];
						}
						oModel.setProperty("/Observer/PartnerNo", locData.bupakey);
						oModel.setProperty("/Observer/Fullname", locData.name); /* Copying and maping data to local model type and subtype entity */
					}, // model read success
					error: function(aData, response) {
							MessageBox.error("You are not classified as a Reporter. You can't create a Field Event.", {
								onClose: function() {
									that.getRouter().navTo("worklist");
								}
							});
						} // model read error
				}); // model.read('/CselItemTypeSet'

				//var sGuidObj = "0060568C-3768-1EE7-9BAC-749CD9521318";
				var sGuidObj = formatter.uuidCompact();
				sGuid = sGuidObj;
				//sGuid = dModel.createKey("FieldEventExtSet", {
				//	Guid: sGuidObj
				//});
				//oModel.setProperty("/Observer/RefGuid", sGuidObj);
				oModel.setProperty("/Guid", sGuidObj);
				var oViewModel = this.getModel("objectView");
				oViewModel.setProperty("/busy", false);
			}.bind(this));
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf technipfmc.view.CreateEvt
		 */
		onBeforeRendering: function() {

		},
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf technipfmc.view.CreateEvt
		 */
		onAfterRendering: function() {
			//			MessageToast.show("Test");
		},
		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf technipfmc.view.CreateEvt
		 */
		onExit: function() {
			for (var x = 0; x < reqElemData.length; x++) {
				this.getView().byId(reqElemData[x].elem).setValueState("None");
			}
		},

		formatAttribute: function(sValue) {
			jQuery.sap.require("sap.ui.core.format.FileSizeFormat");
			if (jQuery.isNumeric(sValue)) {
				return sap.ui.core.format.FileSizeFormat.getInstance({
					binaryFilesize: false,
					maxFractionDigits: 1,
					maxIntegerDigits: 3
				}).format(sValue);
			} else {
				return sValue;
			}
		},

		formatCheck: function(sValue) {
			return sValue === "X";
		},

		/**
		 *@memberOf technipfmc.controller.CreateEvt
		 */
		onEvtSave: function() {
			//This code was generated by the layout editor.
			var oModel = this.getView().getModel("CreateEvt");
			var oView = this.getView();
			var errExist;

			for (var x = 0; x < reqElemData.length; x++) {
				if (oView.byId(reqElemData[x].elem).getMetadata().getName() !== "sap.m.Select") {
					if (!oView.byId(reqElemData[x].elem).getValue()) {
						oView.byId(reqElemData[x].elem).setValueState("Error");
						errExist = true;
					} else {
						oView.byId(reqElemData[x].elem).setValueState("None");
					}
				}
				if (oView.byId(reqElemData[x].elem).getMetadata().getName() === "sap.m.Select") {
					if (!oView.byId(reqElemData[x].elem).getSelectedKey()) {
						oView.byId(reqElemData[x].elem).setValueState("Error");
						errExist = true;
					} else {
						oView.byId(reqElemData[x].elem).setValueState("None");
					}
				}
			}

			if (errExist) {
				MessageBox.error("Please fill all the required fields.");
				//MessageToast.show("Please fill all the required fields.");
				return;
			}

			var dModel = this.getView().getModel();
			MessageToast.show("Saving Order...");
			that = this;
			var oViewModel = this.getModel("objectView");
			oViewModel.setProperty("/busy", true);
			if (!sap.hybrid) {
				dModel.create("/FieldEventExtSet", oModel.getData(), {
					success: function(aData, response) {
						var locData = aData;
						that.getModel("objectView").setProperty("/busy", false);
						MessageBox.success("Field Event successfully created with no " + locData.ObjectId + ".", {
							onClose: function() {
								that.getRouter().navTo("object", {
									objectId: locData.Guid
								});
							}
						});

					}, // model read success
					error: function(aData, response) {
							that.getModel("objectView").setProperty("/busy", false);
							MessageBox.error("Field Event creation failed.");
						} // model read success
				});
			} else {
				var changeSetId = sGuid;
				dModel.setDeferredGroups([changeSetId]);
				var mParameters = {
					"groupId": changeSetId,
					"changeSetId": changeSetId,
					"headers": {
						"Content-ID": changeSetId
					}
				}; //I'm using both...maybe one isn't needed??
				var msParameters = {
					"groupId": changeSetId,
					"changeSetId": changeSetId
				}; //I'm using both...maybe one isn't needed??
				var btData = oModel.getData();
				var btAttData = btData.FieldEvent_Attach_nav;
				delete btData.FieldEvent_Attach_nav;
				dModel.create("/FieldEventExtSet", btData, mParameters);
				var sObjectPath = "/$" + changeSetId;
				for (var i = 0; i < btAttData.length; i++) {
					dModel.create(sObjectPath + "/FieldEvent_Attach_nav", btAttData[i], msParameters);
				}
				dModel.submitChanges({
					groupId: changeSetId,
					success: function(aData, response) {
						that.getModel("objectView").setProperty("/busy", false);
						MessageBox.success("Field Event successfully created locally.", {
							onClose: function() {
								that.getView().unbindObject("CreateEvt");
								that.getView().getModel().refresh();
								that.getRouter().navTo("worklist", {}, true);
							}
						});

					}, // model read success
					error: function(aData, response) {
							that.getModel("objectView").setProperty("/busy", false);
							MessageBox.error("Field Event creation failed.");
						} // model read success				
				});
			}
		},

		onChangeValue: function(oEvent) {
			//			var control = evt.getParameter("element");
			//				if (control && control.setValueState) {
			//					control.setValueState("Error");			
			if (oEvent.getSource().getValueState() === "Error") {
				oEvent.getSource().setValueState("None");
			}

			switch (oEvent.getParameter("id")) {
				case this.getView().createId("Zzafld000000"):
					if (oEvent.getParameter("value") !== "" && oEvent.getParameter("value") !== "NA") {
						this.getView().byId("Zzafld000001").setValue("NA");
						if (this.getView().byId("Zzafld000001").getValueState() === "Error") {
							this.getView().byId("Zzafld000001").setValueState("None");
						}
					}
					break;

				case this.getView().createId("Zzafld000001"):
					if (oEvent.getParameter("value") !== "" && oEvent.getParameter("value") !== "NA") {
						this.getView().byId("Zzafld000000").setValue("NA");
						if (this.getView().byId("Zzafld000000").getValueState() === "Error") {
							this.getView().byId("Zzafld000000").setValueState("None");
						}
					}
					break;

				case this.getView().createId("Zzafld00000i"):
					if (oEvent.getParameter("value") !== "") {
						this.getView().byId("ProjectPrtnr_PartnerNo").setValue("From SO");
						this.getView().byId("ClientPrtnr_PartnerNo").setValue("From SO");
						if (this.getView().byId("ProjectPrtnr_PartnerNo").getValueState() === "Error") {
							this.getView().byId("ProjectPrtnr_PartnerNo").setValueState("None");
						}
						if (this.getView().byId("ClientPrtnr_PartnerNo").getValueState() === "Error") {
							this.getView().byId("ClientPrtnr_PartnerNo").setValueState("None");
						}
					}
					break;
			}
		},

		/**
		 *@memberOf technipfmc.controller.CreateEvt
		 */
		onEvtCancel: function() {
			//This code was generated by the layout editor.
			for (var x = 0; x < reqElemData.length; x++) {
				this.getView().byId(reqElemData[x].elem).setValueState("None");
			}
			this.getView().unbindObject("CreateEvt");
			this.getRouter().navTo("worklist");
		},

		onWorkListPress: function() {
			this.getView().unbindObject("CreateEvt");
			this.getRouter().navTo("worklist");
		},

		handlePartSuggest: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onValueHelpPart: function(oEvent) {
				var oView = this.getView();
				// Keep view for value popup
				// Value help for Engineer Id -------------------------------------------------------
				if (!this.oValueHelpDialogPart) {
					// Dialog window not already defined
					// =================== Set up selection dialog window ==========================
					// Create  Dialog + and we attach this as helper
					this.oValueHelpDialogPart = new sap.m.SelectDialog("partValueDialog", {
						title: "Assembly Part Selection Helper",
						noDataText: "No Parts Found",
						rememberSelections: false,
						// Remember previous selection
						confirm: function(oEvent1) {
							// Value selected ----------------------
							// Value from selection – assign value to the field in view
							oView.byId("Zzfld00001w").setValue(oEvent1.getParameter("selectedItem").getTitle());
							oView.byId("Zzfld00001w").setDescription(oEvent1.getParameter("selectedItem").getDescription());
							oView.byId("Zzfld00001w").focus();
							if (oView.byId("Zzfld00001w").getValueState() === "Error") {
								oView.byId("Zzfld00001w").setValueState("None");
							}
						},
						// confirm
						search: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						}, // Search
						cancel: function() {
							oView.byId("Zzfld00001w").focus();
						}
					}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
				}
				// if no exisiting dialog object
				//				var oModelF4 = this.getModel("ALLF4");
				this.oValueHelpDialogPart.setModel(this.getView().getModel());
				var itemTemplate = new sap.m.StandardListItem({
					title: "{ProductId}",
					description: "{ShortText}"
				});
				this.oValueHelpDialogPart.bindAggregation("items", "/F4ProductSet", itemTemplate);
				this.oValueHelpDialogPart.open(this.oValueHelpDialogPart._sSearchFieldValue);
			} // onValueHelpPart
			,

		onValueHelpPartfp: function(oEvent) {
				var oView = this.getView();
				// Keep view for value popup
				// Value help for Engineer Id -------------------------------------------------------
				if (!this.oValueHelpDialogPartfp) {
					// Dialog window not already defined
					// =================== Set up selection dialog window ==========================
					// Create  Dialog + and we attach this as helper
					this.oValueHelpDialogPartfp = new sap.m.SelectDialog("partValueDialogfp", {
						title: "Assembly Part Selection Helper",
						noDataText: "No Parts Found",
						rememberSelections: false,
						// Remember previous selection
						confirm: function(oEvent1) {
							// Value selected ----------------------
							// Value from selection – assign value to the field in view
							oView.byId("Zzfld00001u").setValue(oEvent1.getParameter("selectedItem").getTitle());
							oView.byId("Zzfld00001u").setDescription(oEvent1.getParameter("selectedItem").getDescription());
							oView.byId("Zzfld00001u").focus();
							if (oView.byId("Zzfld00001u").getValueState() === "Error") {
								oView.byId("Zzfld00001u").setValueState("None");
							}
						},
						// confirm
						search: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						}, // Search
						cancel: function() {
							oView.byId("Zzfld00001u").focus();
						}
					}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
				}
				// if no exisiting dialog object
				//				var oModelF4 = this.getModel("ALLF4");
				this.oValueHelpDialogPartfp.setModel(this.getView().getModel());
				var itemTemplate = new sap.m.StandardListItem({
					title: "{ProductId}",
					description: "{ShortText}"
				});
				this.oValueHelpDialogPartfp.bindAggregation("items", "/F4ProductSet", itemTemplate);
				this.oValueHelpDialogPartfp.open(this.oValueHelpDialogPartfp._sSearchFieldValue);
			} // onValueHelpPart
			,
		/**
		 *@memberOf technipfmc.controller.CreateEvt
		 */
		onValueHelpSerial: function() {
			var oView = this.getView();
			// Keep view for value popup
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogSer) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogSer = new sap.m.SelectDialog("serialValueDialog", {
					title: "Assembly Serial Selection Helper",
					noDataText: "No Serial Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("Zzfld00001y").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("Zzfld00001y").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("Zzfld00001x").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("Zzfld00001w").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("Zzfld00001y").getValueState() === "Error") {
							oView.byId("Zzfld00001y").setValueState("None");
						}
						if (oView.byId("Zzfld00001x").getValueState() === "Error") {
							oView.byId("Zzfld00001x").setValueState("None");
						}
						if (oView.byId("Zzfld00001w").getValueState() === "Error") {
							oView.byId("Zzfld00001w").setValueState("None");
						}
						oView.byId("Zzfld00001y").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3serNo", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("Zzfld00001y").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogSer.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3serNo}",
				description: "Equipment : {R3ident} - {ShortText}",
				info: "Material : {R3matId}"
			});
			this.oValueHelpDialogSer.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogSer.open(this.oValueHelpDialogSer._sSearchFieldValue);
		},

		onValueHelpSerialfp: function() {
			var oView = this.getView();
			// Keep view for value popup
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogSerfp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogSerfp = new sap.m.SelectDialog("serialValueDialogfp", {
					title: "Assembly Serial Selection Helper",
					noDataText: "No Serial Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("ZzorderadmH1109").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("ZzorderadmH1109").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("Zzafld00003m").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("Zzfld00001u").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("ZzorderadmH1109").getValueState() === "Error") {
							oView.byId("ZzorderadmH1109").setValueState("None");
						}
						if (oView.byId("Zzafld00003m").getValueState() === "Error") {
							oView.byId("Zzafld00003m").setValueState("None");
						}
						if (oView.byId("Zzfld00001u").getValueState() === "Error") {
							oView.byId("Zzfld00001u").setValueState("None");
						}
						oView.byId("ZzorderadmH1109").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3serNo", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("ZzorderadmH1109").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogSerfp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3serNo}",
				description: "Equipment : {R3ident} - {ShortText}",
				info: "Material : {R3matId}"
			});
			this.oValueHelpDialogSerfp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogSerfp.open(this.oValueHelpDialogSerfp._sSearchFieldValue);
		},

		onValueHelpEquip: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogEqp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogEqp = new sap.m.SelectDialog("eqpValueDialog", {
					title: "Assembly Equipment Search Criteria",
					noDataText: "No Equipment Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("Zzfld00001y").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("Zzfld00001y").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("Zzfld00001x").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("Zzfld00001w").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("Zzfld00001y").getValueState() === "Error") {
							oView.byId("Zzfld00001y").setValueState("None");
						}
						if (oView.byId("Zzfld00001x").getValueState() === "Error") {
							oView.byId("Zzfld00001x").setValueState("None");
						}
						if (oView.byId("Zzfld00001w").getValueState() === "Error") {
							oView.byId("Zzfld00001w").setValueState("None");
						}
						oView.byId("Zzfld00001y").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3ident", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("Zzfld00001y").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogEqp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3ident} - {ShortText}",
				description: "Material : {R3matId}",
				info: "Serial : {R3serNo}"
			});
			this.oValueHelpDialogEqp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogEqp.open(this.oValueHelpDialogEqp._sSearchFieldValue);
		},

		onValueHelpEquipfp: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogEqpfp) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogEqpfp = new sap.m.SelectDialog("eqpValueDialogfp", {
					title: "Assembly Equipment Selection Helper",
					noDataText: "No Equipment Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						oView.byId("ZzorderadmH1109").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3ident"));
						oView.byId("ZzorderadmH1109").setDescription(oEvent1.getParameter("selectedItem").getBindingContext().getObject("ShortText"));
						oView.byId("Zzafld00003m").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3serNo"));
						oView.byId("Zzfld00001u").setValue(oEvent1.getParameter("selectedItem").getBindingContext().getObject("R3matId"));
						if (oView.byId("ZzorderadmH1109").getValueState() === "Error") {
							oView.byId("ZzorderadmH1109").setValueState("None");
						}
						if (oView.byId("Zzafld00003m").getValueState() === "Error") {
							oView.byId("Zzafld00003m").setValueState("None");
						}
						if (oView.byId("Zzfld00001u").getValueState() === "Error") {
							oView.byId("Zzfld00001u").setValueState("None");
						}
						oView.byId("ZzorderadmH1109").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("R3ident", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("ZzorderadmH1109").focus();
					}
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogEqpfp.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{R3ident} - {ShortText}",
				description: "Material : {R3matId}",
				info: "Serial : {R3serNo}"
			});
			this.oValueHelpDialogEqpfp.bindAggregation("items", "/F4EquipSet", itemTemplate);
			this.oValueHelpDialogEqpfp.open(this.oValueHelpDialogEqpfp._sSearchFieldValue);
		},

		onValueHelpClient: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogClnt) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogClnt = new sap.m.SelectDialog("clntValueDialog", {
					title: "Client Selection Helper",
					noDataText: "No Client Found",
					rememberSelections: true,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("ClientPrtnr_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						oView.getModel("CreateEvt").setProperty("/ClientPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("ClientPrtnr_PartnerNo").getValueState() === "Error") {
							oView.byId("ClientPrtnr_PartnerNo").setValueState("None");
						}
						oView.byId("ClientPrtnr_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("ClientPrtnr_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search						

				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogClnt.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "CRM000");
			this.oValueHelpDialogClnt.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogClnt.open(this.oValueHelpDialogClnt._sSearchFieldValue);
		},

		onValueHelpOwner: function() {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogOwner) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogOwner = new sap.m.SelectDialog("ownValueDialog", {
					title: "Owner Selection Helper",
					noDataText: "No Owner Found",
					rememberSelections: false,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("EvtOwner_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						//oView.byId("EvtOwner_PartnerNo").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.getModel("CreateEvt").setProperty("/EvtOwner/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("EvtOwner_PartnerNo").getValueState() === "Error") {
							oView.byId("EvtOwner_PartnerNo").setValueState("None");
						}
						oView.byId("EvtOwner_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("EvtOwner_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search						
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogOwner.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "BUP003");
			this.oValueHelpDialogOwner.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogOwner.open(this.oValueHelpDialogOwner._sSearchFieldValue);
		},

		onValueHelpPrj: function(oEvent) {
			var oView = this.getView();
			// Keep view for value popup f
			// Value help for Engineer Id -------------------------------------------------------
			if (!this.oValueHelpDialogPrj) {
				// Dialog window not already defined
				// =================== Set up selection dialog window ==========================
				// Create  Dialog + and we attach this as helper
				this.oValueHelpDialogPrj = new sap.m.SelectDialog("prjValueDialog", {
					title: "Project Selection Helper",
					noDataText: "No Project Found",
					rememberSelections: true,
					// Remember previous selection
					confirm: function(oEvent1) {
						// Value selected ----------------------
						// Value from selection – assign value to the field in view
						//oView.byId("ClientPrtnr_Fullname").setValue(oEvent1.getParameter("selectedItem").getTitle());
						//oView.byId("Zzafld000024").setDescription(oEvent1.getParameter("selectedItem").getDescription());
						oView.byId("ProjectPrtnr_PartnerNo").setValue(oEvent1.getParameter("selectedItem").getDescription());
						oView.getModel("CreateEvt").setProperty("/ProjectPrtnr/PartnerNo", oEvent1.getParameter("selectedItem").getTitle());
						if (oView.byId("ProjectPrtnr_PartnerNo").getValueState() === "Error") {
							oView.byId("ProjectPrtnr_PartnerNo").setValueState("None");
						}
						oView.byId("ProjectPrtnr_PartnerNo").focus();
					},
					// confirm
					search: function(oEvent2) {
						// Search ----------------
						var sValue = oEvent2.getParameter("value");
						// Search value
						var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
						var oBinding = oEvent2.getSource().getBinding("items");
						oBinding.filter(oFilter2);
					}, // Search
					cancel: function() {
						oView.byId("ProjectPrtnr_PartnerNo").focus();
					},
					liveChange: function(oEvent2) {
							// Search ----------------
							var sValue = oEvent2.getParameter("value");
							// Search value
							var oFilter2 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
							var oBinding = oEvent2.getSource().getBinding("items");
							oBinding.filter(oFilter2);
						} // Search						
				}); // this.oValueHelpDialogEng = new sap.m.SelectDialog
			}
			// if no exisiting dialog object
			//				var oModelF4 = this.getModel("ALLF4");
			this.oValueHelpDialogPrj.setModel(this.getView().getModel());
			var itemTemplate = new sap.m.StandardListItem({
				title: "{bupakey}",
				description: "{name}"
			});
			var oFilter1 = new sap.ui.model.Filter("PARTNROLE", sap.ui.model.FilterOperator.EQ, "ZPROJE");
			this.oValueHelpDialogPrj.bindAggregation("items", {
				path: "/F4PartnerSet",
				template: itemTemplate,
				filters: [oFilter1]
			});
			this.oValueHelpDialogPrj.open(this.oValueHelpDialogPrj._sSearchFieldValue);
		},

		onFileUploadComplete: function(oEvent) {
			//			var that = this;
			//			that.messagesModel.setProperty("/messages", []);
			//			var messages = [];
			var oViewDet = this.getView();
			var sRefGuid;
			//var sRefGuid = oViewDet.getBindingContext().getProperty("Guid"); // Guid

			var oModel = this.getView().getModel("CreateEvt");
			// ------------------------- Read file content ----------------------------------
			var oFileUploader = this.getView().byId("fileUploaderCrt");
			var oFile = jQuery.sap.domById(oFileUploader.getId() + "-fu").files[0];
			var sFileName = oFile.name;
			// Name of file
			var sMimeType = oFile.type;
			// Type of file
			var sFilesize = oFile.size;
			var sBase64Mark = "data:" + oFile.type + ";base64,";
			// File content prefix to remove
			var oReader = new FileReader();
			// Set up file reader
			var re =
				/(\.|\/)(bat|exe|cmd|sh|php([0-9])?|pl|cgi|386|dll|com|torrent|js|app|jar|pif|vb|vbscript|wsf|asp|cer|csr|jsp|drv|sys|ade|adp|bas|chm|cpl|crt|csh|fxp|hlp|hta|inf|ins|isp|jse|htaccess|htpasswd|ksh|lnk|mdb|mde|mdt|mdw|msc|msi|msp|mst|ops|pcd|prg|reg|scr|sct|shb|shs|url|vbe|vbs|wsc|wsf|wsh)$/i;

			if (sFilesize > 40000000) {
				MessageBox.error("File Size exceeds the limit of 40 MB.");
				return;
			}
			if (re.exec(sFileName)) {
				MessageBox.error("This file type is not allowed for upload.");
				return;
			}
			// ---------------------- Routine to start when file loaded ------------------------
			oReader.onload = function(oFileRead) {
				// Locate base64 content
				var sObjId = oModel.getProperty("/FieldEvent_Attach_nav").length + 1;
				var iBase64Index = oFileRead.target.result.indexOf(sBase64Mark) + sBase64Mark.length;
				// Get base64 content
				var sFileContent = oFileRead.target.result.substring(iBase64Index);
				var aData = {
					// Backend action record&nbsp;
					//RefHandle: "0001",
					RefGuid: sGuid,
					ObjId: sObjId.toString(),
					FileName: sFileName,
					MimeType: sMimeType,
					FileSize: sFilesize,
					FileContent: sFileContent
				};
				oModel.getProperty("/FieldEvent_Attach_nav").push(aData);
				oModel.refresh(); //oModel.updateBindings();
			};
			// oReader.onload function
			oReader.readAsDataURL(oFile); // Read file encoded to base64
		},

		/** ---------------------------------------------------------------------------------
		 **  method displayAttachment
		 **  Display one attachment.
		 * @param {object} oEvent  The event object from the press event
		 **----------------------------------------------------------------------------------*/
		onAttDisplayPress: function(oEvent) {
			var oDataFound = oEvent.getSource().getBindingContext("CreateEvt").getObject();
			//------------------------ Open a window with file content ------------------------------
			// Convert to byteArray
			if (oDataFound) {
				//------------------------ Open a window with file content ------------------------------
				var decodedData = atob(oDataFound.FileContent);
				// Decode from base64
				// Convert to byteArray
				var byteNumbers = new Array(decodedData.length);
				for (var i = 0; i < decodedData.length; i++) {
					byteNumbers[i] = decodedData.charCodeAt(i);
				}
				// for
				var byteArrays = [new Uint8Array(byteNumbers)];
				// BLOB for file save
				var oBlob = new Blob(byteArrays, {
					type: oDataFound.MimeType
				});
				if (window.navigator.msSaveBlob) {
					// IE hack - see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
					window.navigator.msSaveOrOpenBlob(oBlob, oDataFound.FileName);
				} else {
					if (!sap.hybrid) {
						var a = window.document.createElement("a");
						a.href = window.URL.createObjectURL(oBlob, {
							type: oDataFound.MimeType
						});
						a.download = oDataFound.FileName;
						// Name of file
						document.body.appendChild(a);
						a.click();
						document.body.removeChild(a);
					} else {
						window.open(window.URL.createObjectURL(oBlob, {
							type: oDataFound.MimeType
						}));
					}
				} // if
			} // File content found
		},
		// displayAttachment		
		/** ---------------------------------------------------------------------------------
		 **  method onCSELAttachDelete
		 **  Delete selected attachments.
		 * @param {object} oEvent  The event object from the press event
		 **----------------------------------------------------------------------------------*/
		onFileDeleted: function(oEvent) {
			var oModel = this.getView().getModel("CreateEvt");
			var sPath = oEvent.getSource().getBindingContext("CreateEvt").getPath();
			// Path to file
			var iIndex = sPath.slice(sPath.length - 1);
			oModel.getProperty("/FieldEvent_Attach_nav").splice(iIndex, 1);
			oModel.refresh();
		}

	});
});