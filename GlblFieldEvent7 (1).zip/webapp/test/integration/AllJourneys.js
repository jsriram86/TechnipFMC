jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"technipfmc/gfe/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"technipfmc/gfe/test/integration/pages/Worklist",
		"technipfmc/gfe/test/integration/pages/Object",
		"technipfmc/gfe/test/integration/pages/NotFound",
		"technipfmc/gfe/test/integration/pages/Browser",
		"technipfmc/gfe/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "technipfmc.gfe.view."
	});

	sap.ui.require([
		"technipfmc/gfe/test/integration/WorklistJourney",
		"technipfmc/gfe/test/integration/ObjectJourney",
		"technipfmc/gfe/test/integration/NavigationJourney",
		"technipfmc/gfe/test/integration/NotFoundJourney",
		"technipfmc/gfe/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});